<?php
namespace App\Http\Controllers\Api;

class CustomerController {

    public function index() {
        return response()->json([]);
    }

    public function store() {
        return response()->json(['message' => 'created']);
    }
}
