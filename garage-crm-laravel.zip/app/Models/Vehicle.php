<?php
namespace App\Models;

class Vehicle {
    public $id;
    public $customer_id;
    public $model;
    public $plate;
}
