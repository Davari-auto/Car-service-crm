<?php
namespace App\Models;

class ServiceOrder {
    public $id;
    public $vehicle_id;
    public $status;
    public $cost;
}
