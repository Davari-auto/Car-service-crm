<?php
namespace App\Models;

class Customer {
    public $id;
    public $name;
    public $phone;
}
